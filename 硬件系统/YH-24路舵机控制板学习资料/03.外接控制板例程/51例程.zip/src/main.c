/*
单片机：STC15W4K61S4/IAP15W4K61S4 内部晶振：22.1184	
*/
#include "stc15.h"

#define FOSC 22118400L          //
#define BAUD 115200L            //

#define S2RI  0x01    			//
#define S2TI  0x02   			// 

#define ISPPROGRAM() ((void(code*)())0xF000)()

u8 busy2 = 0;
u32 uart_timeout = 0;

void uart1_init(void);
void uart1_send_byte(u8 dat);
void uart1_send_str(char *s);
void uart1_close(void);
void uart1_open(void);

void uart2_init(void);
void uart2_send_byte(u8 dat);
void uart2_send_str(char *s);
void uart2_close(void);
void uart2_open(void);

void zx_uart_send_str(char *s);
void delay_ms(unsigned int t);		//简单的延时


void main(void) {
	//串口1初始化
	uart1_init();
	//uart1_close();
	uart1_open();
	
	//串口2初始化
	uart2_init();
	//uart2_close();
	uart2_open();
    while (1) {
		uart1_send_str((u8 *)"$DGT:0-4,1!");	//串口1 调用 0到4 动作，执行1次 其他命令参照控制器指令
		zx_uart_send_str((u8 *)"$DGT:0-4,1!");	//总线口 调用 0到4 动作，执行1次 其他命令参照控制器指令
		delay_ms(10000);						//延时10秒	
	}
}

void delay_ms(unsigned int t) {
	int t1;
	while(t--) {
		t1 = 3000;
		while(t1--);
	}
}

void uart1_init(void) {
	SCON |= 0x50;       //
	T2L = (65536 - (FOSC/4/BAUD));
	T2H = (65536 - (FOSC/4/BAUD))>>8;
	AUXR |= 0x15;       //
	PCON = 0;//0x7F;    //
	EA = 1;   
	ES = 1;             //	
}

void uart2_init(void) {
	S2CON = 0x50;         //
	T2L = (65536 - (FOSC/4/BAUD));    //
	T2H = (65536 - (FOSC/4/BAUD))>>8; //
	IE2 = 0x01;
	EA = 1; 
	P_SW2 |= 0x01;	//TX2 4.7 RX2 4.6	
}

void uart1_open(void) {
	ES = 1;
}

void uart1_close(void) {
	ES = 0;
}

void uart2_open(void) {
	//ES2 = 1;
	IE2 = 0x01; 
}

void uart2_close(void) {
	//ES2 = 0;
	IE2 = 0x00; 
}


/*----------------------------

----------------------------*/
void uart1_send_byte(u8 dat) {
    SBUF = dat;   
    while(TI == 0);   
    TI = 0; 
}

void uart2_send_byte(u8 dat) {
    S2BUF = dat;   
	while(!(S2CON & S2TI));
	S2CON &= ~S2TI; 
}

/*----------------------------

----------------------------*/
void uart1_send_str(char *s) {
    while (*s) {                  	//
        uart1_send_byte(*s++);         //
    }
}

void uart2_send_str(char *s) {
    while (*s) {                  		//
        uart2_send_byte(*s++);         //
    }
}

void zx_uart_send_str(char *s) {
    while (*s) {                  		//
        uart2_send_byte(*s++);         //
    }
}


/*----------------------------

串口中断函数

-----------------------------*/
void Uart() interrupt 4 using 1 {
	static u16 buf_index = 0;
	static u8 sbuf_bak;
	
    if (RI) {
		sbuf_bak = SBUF;
		RI = 0;                 
    }
	
//    if (TI) {
//        TI = 0;                 
//    }
}

void UART2_Int(void) interrupt  8 using 1
{
	static u16 buf_index = 0;
	static u8 sbuf_bak;
	if(S2CON&S2RI)		  		
	{   
		sbuf_bak = S2BUF;
		S2CON &= ~S2RI;
		
	}
	
//	if (S2CON&S2TI)// ½ÓÊÕµ½·¢ËÍÃüÁî
//	{
//		busy2 = 0;
//	}
}

